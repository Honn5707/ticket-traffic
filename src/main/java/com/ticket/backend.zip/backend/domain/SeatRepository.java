package com.ticket.backend.domain;

import org.springframework.data.jpa.repository.JpaRepository;

//seat테이블을 관리하는 규칙

public  interface SeatRepository extends JpaRepository<Seat, Long>{
}