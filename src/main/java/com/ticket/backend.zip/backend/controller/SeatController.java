package com.ticket.backend.controller;

import com.ticket.backend.domain.Seat;
import com.ticket.backend.domain.SeatRepository;
import com.ticket.backend.service.SeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.ticket.backend.dto.SeatResponse;
import java.util.stream.Collectors;

import java.util.List;

@RestController
@RequestMapping("/api/seats")
@RequiredArgsConstructor
public class SeatController {
    private final SeatService seatService;

    @GetMapping
    public List<SeatResponse> getAllSeats() {
        // 1. 서비스에서 모든 좌석 엔티티를 가져옵니다.
        // 2. .stream()을 이용해 SeatResponse(DTO)로 옷을 갈아입힙니다.
        return seatService.findAll().stream()
                .map(SeatResponse::new)
                .collect(Collectors.toList());
    }
    // 테스트를 위해 잠시 @GetMapping으로 바꿀게요! (브라우저 주소창에서 바로 엔터 치려고요)
    @GetMapping("/{seatId}/reserve")
    public String reserveSeat(@PathVariable Long seatId) {
        seatService.reserve(seatId);
        return "좌석 " + seatId + "번 예약 성공!";
    }

    @GetMapping("/init") // 초기화
    public String initSeats(){
        int count = 100;
        long startTime = System.currentTimeMillis(); //시간재기

        seatService.createSeats(count);

        long endTime = System.currentTimeMillis();

        //걸린 시간(ms)을 알려줍니다
        return count + "개 좌석 생성 완료! 걸린시간:" + (endTime - startTime) + "ms)";
    }

}