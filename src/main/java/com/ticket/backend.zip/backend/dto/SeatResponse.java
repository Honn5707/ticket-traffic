package com.ticket.backend.dto;

import com.ticket.backend.domain.Seat;
import lombok.Getter;

@Getter
public class SeatResponse {
    private Long id;
    private int seatNumber;
    private boolean isReserved;

    //엔티티를 DTO로
    public  SeatResponse(Seat seat) {

        this.id = seat.getId();
        this.seatNumber = seat.getSeatNumber();
        this.isReserved = seat.isReserved();
    }
}
